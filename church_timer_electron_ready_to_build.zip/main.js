
const { app, BrowserWindow, screen, ipcMain } = require('electron');

let controlWindow;
let timerWindow;

function createWindows() {
  const displays = screen.getAllDisplays();
  const primaryDisplay = screen.getPrimaryDisplay();
  const externalDisplay = displays.find(d => d.id !== primaryDisplay.id) || primaryDisplay;

  // Control window
  controlWindow = new BrowserWindow({
    width: 500,
    height: 400,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    }
  });
  controlWindow.loadFile('control.html');

  // Display (timer) window
  timerWindow = new BrowserWindow({
    x: externalDisplay.bounds.x,
    y: externalDisplay.bounds.y,
    fullscreen: true,
    frame: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    }
  });
  timerWindow.loadFile('display.html');

  ipcMain.on('timer-update', (e, time) => {
    if (timerWindow) {
      timerWindow.webContents.send('timer-display', time);
    }
  });

  controlWindow.on('closed', () => {
    timerWindow.close();
  });
}

app.whenReady().then(createWindows);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
